using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class manager : MonoBehaviour
{
    public static manager instance;

    public GameObject[] target;
    public GameObject player;
    [HideInInspector]
    public int score;
   

    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        Uimanager.instance.highscore_text.text = "" + PlayerPrefs.GetInt("highScore", 0).ToString();
        Uimanager.instance.losscreen_highscore_text.text = "Best Score: " + PlayerPrefs.GetInt("highScore", 0).ToString();
        AudioManager.instance.Play("Music");
       
    }

    // Update is called once per frame
    void Update()
    {
        Uimanager.instance.score_text.text = "" + score;
        Uimanager.instance.losscreen_score_text.text = "Score  " + score;
        if (score > PlayerPrefs.GetInt("highScore", 0))
        {
            PlayerPrefs.SetInt("highScore", score);
            Uimanager.instance.highscore_text.text = score.ToString();
            Uimanager.instance.losscreen_highscore_text.text = "Best Score: " + score;

        }

        //Uimanager.instance.Record_highscore_text.text = "Best Score " + highscore;

    }
   public void spawn()
    {
        float randomx = Random.Range(-2.2f, 2.2f);
        Vector3 randompos = new Vector3(randomx, 3.24f, 0f);
        Instantiate(target[0], randompos, Quaternion.identity);
    }
    public void spawn1()
    {
        float randomx = Random.Range(-2.2f, 2.2f);
        Vector3 randompos = new Vector3(randomx, 3.24f, 0f);
        Instantiate(target[1], randompos, Quaternion.identity);
    }
    public void spawn2()
    {
        float randomx = Random.Range(-2.2f, 2.2f);
        Vector3 randompos = new Vector3(randomx, 3.24f, 0f);
        Instantiate(target[2], randompos, Quaternion.identity);
    }
    public  void spawnPlayer()
    {
        Instantiate(player);
    }
    public void spawnenemyandplayer()
    {
        if (Uimanager.instance.menustate == 0)
        {
            InvokeRepeating("spawn", 1f, 4.5f);
            InvokeRepeating("spawn1", 3f, 2f);
            InvokeRepeating("spawn2", 4f, 8f);

            spawnPlayer();
        }
        
    }
    public void cancelInvokespawn()
    {
        CancelInvoke("spawn");
        CancelInvoke("spawn1");
        CancelInvoke("spawn2");
    }
}