using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{

    private float speed = 4;
    private Vector2 lastClickedPos;
    private bool moving = false;


    void Update()
    {
        if (Input.GetMouseButtonDown(1));
        {
            lastClickedPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            moving = true;
        }
        if (moving && (Vector2)transform.position != lastClickedPos)
        {
            float step = speed * Time.deltaTime;
            transform.position = Vector2.MoveTowards(transform.position, lastClickedPos, step);
        }
        else
        {
            moving = false;
        }
        if (Uimanager.instance.menustate == 1)
        {
            Destroy(gameObject);
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "object")
        {
            Debug.Log("vibrate");
            AudioManager.instance.VibrationButton();

            StartCoroutine(waittime());
            manager.instance.cancelInvokespawn();
            Uimanager.instance.looseScreen.SetActive(true);
            Uimanager.instance.Pausebtn.SetActive(true);
           
            // collision.gameObject.SendMessage("ApplyDamage", 10);
        }
    }

    IEnumerator waittime()
    {
        yield return new WaitForSeconds(0.3f);
        Destroy(gameObject);
    }



}
