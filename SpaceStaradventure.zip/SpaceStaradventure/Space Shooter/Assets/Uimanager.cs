using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Uimanager : MonoBehaviour
{
    public static Uimanager instance;

    public TextMeshProUGUI score_text;
    public TextMeshProUGUI highscore_text;
    public TextMeshProUGUI losscreen_score_text;
    public TextMeshProUGUI losscreen_highscore_text;
    
    public GameObject Mainmenu;
    public GameObject SettingPanel;
    public GameObject PauseSceen;
    public GameObject looseScreen;
    public GameObject Pausebtn;
    
    public int menustate;

    // Start is called before the first frame update
    private void Awake()
    {
        instance = this;
    }
    void Start()
    {
        menustate = 0;
    }

    // Update is called once per frame
    void Update()
    {
       

    }
    public void play()
    {
        menustate = 0;
        Mainmenu.SetActive(false);
        manager.instance.spawnenemyandplayer();
        AudioManager.instance.VibrationButton();
        AudioManager.instance.Play("Button");
    }
    public void QuitGame()
    {
        Application.Quit();
    }
    public void settingspanel()
    {
        SettingPanel.SetActive(true);
        Mainmenu.SetActive(false);
        AudioManager.instance.Play("Button");
    }
    public void pauseceen()
    {
        PauseSceen.SetActive(true);
        Time.timeScale = 0;
        AudioManager.instance.Play("Button");
    }
    public void returntogame()
    {
        AudioManager.instance.Play("Button");
        PauseSceen.SetActive(false);
        Time.timeScale = 1;
        
    }
    public void restart()
    {
        AudioManager.instance.Play("Button");
        PauseSceen.SetActive(false);
        Time.timeScale = 1;
        manager.instance.score = 0;
        
    }
    public void restartforLoose()
    {
        AudioManager.instance.Play("Button");
        looseScreen.SetActive(false);
        manager.instance.score = 0;
        manager.instance.spawnenemyandplayer();
        Pausebtn.SetActive(true);
    }
    public void loosetomenu()
    {
        AudioManager.instance.Play("Button");
        looseScreen.SetActive(false);
        Mainmenu.SetActive(true);
        Pausebtn.SetActive(true);
    }
    public void Gametomenu()
    {
        AudioManager.instance.Play("Button");
        menustate = 1;
        Time.timeScale = 1;
        PauseSceen.SetActive(false);
        Mainmenu.SetActive(true);
        manager.instance.score = 0;
    }
    public void cancelsettingpanel()
    {
        AudioManager.instance.Play("Button");
        SettingPanel.SetActive(false);
        Mainmenu.SetActive(true);
    }

    public void QuitGamepaly()
    {
        Application.Quit();
    }
   
}
