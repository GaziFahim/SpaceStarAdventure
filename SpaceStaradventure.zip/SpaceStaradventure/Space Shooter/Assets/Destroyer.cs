using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroyer : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Uimanager.instance.menustate == 1)
        {
            Destroy(gameObject);
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "shield")
        {
            Destroy(gameObject);
            manager.instance.score++;
            // collision.gameObject.SendMessage("ApplyDamage", 10);
        }

       
    }
}
